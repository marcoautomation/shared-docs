Fearless tests in Eclipse's JUnit view
=======================================

Full writeup: https://marcoautomation.github.io/shared-docs/fearless/eclipse-tests/

What is in this zip
--------------------
- eclipse-junit-xml-reports.patch
    A small, test-only patch to Coordinator/test/integrationTests/RunIntegration.java.
    After each Fearless integration-test project runs, it converts that project's
    newest .out/logs/_base/unit_test_log*.log into a standard JUnit XML report at
    Coordinator/.out/eclipse-junit-xml/TEST-<project>.xml. Apply from inside a
    Coordinator checkout with:

        git apply eclipse-junit-xml-reports.patch

    Then rebuild and run tests as usual (the console-launcher script, or Eclipse's
    own Run As > JUnit Test). This is also up as a small pull request against
    FearlessLang/Coordinator, so it may already be merged upstream by the time
    you read this - check before applying by hand.

- FearlessJUnitXml.java
    The same conversion, as a standalone, dependency-free, single-file Java
    program. Works against any Fearless project that uses base.UnitTests,
    not just the three Coordinator ships. Run it directly (Java 11+, no
    compile step needed):

        java FearlessJUnitXml.java <fearlessProjectRoot> [suiteName] [outDir]

    Example:

        java FearlessJUnitXml.java C:\myFearlessProject myProject
        -> C:\myFearlessProject\.out\eclipse-junit-xml\TEST-myProject.xml

Using the generated XML in Eclipse
-----------------------------------
1. Window > Show View > Other... > Java > JUnit, if the JUnit view is not
   already open.
2. Click the small dropdown arrow next to the "Test Run History" (clock)
   icon in the JUnit view's toolbar, choose Import..., and pick the
   TEST-*.xml file you want to inspect.
3. Eclipse rebuilds the whole run as a real tree: one node per Fearless-level
   check, individually pass/fail/skip, with full failure detail (expected/
   actual/stack trace) on anything red.

Known limitations
------------------
- Two steps, not one: you still run the tests, then Import... - Eclipse has
  no stock way to stream an externally-produced report into a live launch.
- No jump-to-source from an imported node (these are .fear files, not
  .java - Eclipse correctly says "Test class not found in selected
  project" on double-click).
- Only projects that actually use base.UnitTests produce a report; nothing
  is written for the others because there is nothing to report.
- The report always reflects the most recent run of that project.
