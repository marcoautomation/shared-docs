import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class FearlessJUnitXml{
  public static void main(String[] args) throws IOException{
    if (args.length < 1 || args.length > 3){
      System.err.println("Usage: java FearlessJUnitXml.java <fearlessProjectRoot> [suiteName] [outDir]");
      System.exit(2);
    }
    var root= Path.of(args[0]).toAbsolutePath().normalize();
    var suiteName= args.length >= 2 ? args[1] : root.getFileName().toString();
    var outDir= args.length >= 3 ? Path.of(args[2]) : root.resolve(".out").resolve("eclipse_junit_xml");
    var logsDir= root.resolve(".out").resolve("logs").resolve("_base");
    Path newest;
    try (Stream<Path> s= Files.list(logsDir)){
      newest= s.filter(p->p.getFileName().toString().startsWith("unit_test_log"))
        .max(Comparator.comparing(p->p.getFileName().toString()))
        .orElseThrow(()->new IllegalStateException("No unit_test_log*.log under "+logsDir));
    }
    var raw= Files.readString(newest);
    var disabled= Pattern.compile("(?m)^PLAN\\|DISABLED\\|([^|]*)\\|([^|]*)\\|([^|]*)\\|([^|]*)$");
    var body= disabled.matcher(raw).replaceAll(mr->
      "<testcase classname=\""+xmlAttr(mr.group(2))+"\" name=\""+xmlAttr(mr.group(3))
      +"\" file=\""+xmlAttr(mr.group(1))+"\" line=\""+mr.group(4)+"\"><skipped/></testcase>");
    body= body.replaceAll("(?m)^PLAN\\|RUN\\|.*$\\r?\\n?","");
    var tests= body.split("<testcase ",-1).length-1;
    var failures= body.split("<failure>",-1).length-1;
    Files.createDirectories(outDir);
    var report= outDir.resolve("all_auto_tests.xml");
    var suites= Files.exists(report) ? readSuites(Files.readString(report)) : new LinkedHashMap<String,String>();
    suites.put(xmlAttr(suiteName), """
<testsuite name="%s" tests="%d" failures="%d" errors="0">
%s</testsuite>
""".formatted(xmlAttr(suiteName),tests,failures,body));
    Files.writeString(report, """
<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
%s</testsuites>
""".formatted(String.join("",suites.values())));
    System.out.println("Wrote "+report+" (suite \""+suiteName+"\": "+tests+" tests, "+failures+" failures; "+suites.size()+" suite(s) total)");
    System.out.println("From log: "+newest);
    System.out.println("In Eclipse: JUnit view toolbar -> Import... -> pick this one file, every time.");
  }
  static LinkedHashMap<String,String> readSuites(String xml){
    var m= new LinkedHashMap<String,String>();
    Matcher mm= Pattern.compile("(?s)<testsuite name=\"(.*?)\".*?</testsuite>\\r?\\n?").matcher(xml);
    while (mm.find()){ m.put(mm.group(1), mm.group()); }
    return m;
  }
  static String xmlAttr(String s){ return s.replace("&","&amp;").replace("<","&lt;").replace("\"","&quot;"); }
}
